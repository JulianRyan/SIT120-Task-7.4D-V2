<script setup>
import './header.css'
</script>

<template>
    <header>
        <div class="container-fluid fixed-top" id="header">
            <div class="row navbar navbar-dark">
                <div class="col p-2 col-auto text-center">
                    <router-link to="/about-us">
                        <img class="col-12 img-fluid" src="/images/logo.png" alt="logo" id="logo">
                    </router-link>
                </div>
                <div class="col-md-auto col-sm-auto col d-lg-none d-md-none">
                    <button class="navbar-toggler float-end" type="button" data-bs-toggle="collapse"
                        data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                        aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                </div>
                <div class="col-lg col-md col-sm col-auto">
                    <div class="row h-50 py-1 d-lg-block">
                        <div class="col align-self-center m-0">
                            <div class="input-group" id="input-group-search">
                                <input type="search"
                                    class="form-control form-control-sm rounded-start-pill d-lg-block d-md-block d-sm-block d-sm-block d-none"
                                    placeholder="Search" aria-label="Search" aria-describedby="search-addon"
                                    id="input-search" />
                                <router-link to="/products" type="button"
                                    class="btn p-1 px-2 rounded-end-pill border-0 d-lg-block d-md-block d-sm-block d-none"
                                    data-mdb-ripple-init id="btn-search">
                                    Search
                                </router-link>
                                <router-link v-if='(this.$route.path != "/checkout")' to="/checkout" type="button"
                                    class="btn p-1 px-2 mx-2 rounded-pill border-0" id="btn-checkout">
                                    Checkout
                                </router-link>
                            </div>
                        </div>
                    </div>
                    <div class="row h-50 d-lg-block d-md-block d-none" id="navbar">
                        <nav class="navbar navbar-expand-md nav-justified h-100 p-0" id="nav">
                            <ul class="collapse navbar-collapse nav-justified me-auto p-0 h-100 navbar-nav">
                                <li v-if='(this.$route.path === "/")' class="nav-item"><a
                                        class="nav-link my-0 text-secondary">Home</a></li>
                                <li v-else class="nav-item"><router-link to="/"
                                        class="nav-link my-0 text-white">Home</router-link></li>
                                <li v-if='(this.$route.path === "/about-us")' class="nav-item"><a
                                        class="nav-link my-0 text-secondary">About
                                        Us</a></li>
                                <li v-else class="nav-item"><router-link to="/about-us"
                                        class="nav-link my-0 text-white">About
                                        Us</router-link></li>
                                <li v-if='(this.$route.path === "/products")' class="nav-item"><a
                                        class="nav-link my-0 text-secondary">Specials</a></li>
                                <li v-else class="nav-item"><router-link to="/products"
                                        class="nav-link my-0 text-white">Specials</router-link></li>
                                <li v-if='(this.$route.path === "/articles")' class="nav-item"><a
                                        class="nav-link my-0 text-secondary">What's
                                        New</a></li>
                                <li v-else class="nav-item"><router-link to="/articles"
                                        class="nav-link my-0 text-white">What's
                                        New</router-link></li>
                                <li v-if='(this.$route.path === "/contact-us")' class="nav-item"><a
                                        class="nav-link my-0 text-secondary">Contact
                                        Us</a></li>
                                <li v-else class="nav-item"><router-link to="/contact-us"
                                        class="nav-link my-0 text-white">Contact
                                        Us</router-link></li>
                            </ul>
                        </nav>
                    </div>
                </div>
            </div>
            <div class="collapse navbar-collapse nav-justified me-auto p-0 d-lg-none d-md-none"
                id="navbarSupportedContent">
                <div class="input-group" id="input-group-search">
                    <input type="search"
                        class="form-control form-control-sm rounded-start-pill d-lg-none d-md-none d-sm-none d-block"
                        placeholder="Search" aria-label="Search" aria-describedby="search-addon" id="input-search" />
                    <router-link to="/products" type="button"
                        class="btn p-1 px-2 rounded-end-pill border-0 d-lg-none d-md-none d-sm-none d-block"
                        data-mdb-ripple-init id="btn-search">
                        Search
                    </router-link>
                </div>
                <ul>
                    <li v-if='(this.$route.path === "/")' class="nav-item"><a
                                        class="nav-link my-2 text-secondary">Home</a></li>
                                <li v-else class="nav-item"><router-link to="/"
                                        class="nav-link my-2 text-white">Home</router-link></li>
                                <li v-if='(this.$route.path === "/about-us")' class="nav-item"><a
                                        class="nav-link my-2 text-secondary">About
                                        Us</a></li>
                                <li v-else class="nav-item"><router-link to="/about-us"
                                        class="nav-link my-2 text-white">About
                                        Us</router-link></li>
                                <li v-if='(this.$route.path === "/products")' class="nav-item"><a
                                        class="nav-link my-2 text-secondary">Specials</a></li>
                                <li v-else class="nav-item"><router-link to="/products"
                                        class="nav-link my-2 text-white">Specials</router-link></li>
                                <li v-if='(this.$route.path === "/articles")' class="nav-item"><a
                                        class="nav-link my-2 text-secondary">What's
                                        New</a></li>
                                <li v-else class="nav-item"><router-link to="/articles"
                                        class="nav-link my-2 text-white">What's
                                        New</router-link></li>
                                <li v-if='(this.$route.path === "/contact-us")' class="nav-item"><a
                                        class="nav-link my-2 text-secondary">Contact
                                        Us</a></li>
                                <li v-else class="nav-item"><router-link to="/contact-us"
                                        class="nav-link my-2 text-white">Contact
                                        Us</router-link></li>
                </ul>
            </div>
        </div>
    </header>
</template>