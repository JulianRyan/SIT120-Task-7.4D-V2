<script setup>
import './privacy-policy.css'
import { ref, defineProps } from 'vue';

const props = defineProps({
    modalId: String,
});

const modalId = ref(props.modalId).value;
</script>

<template>
    <div class="modal fade" :id="modalId" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
        aria-labelledby="privacyPolicyLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-scrollable">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="privacyPolicyLabel">Privacy Policy</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <h4>Privacy Policy</h4>
                    <p>- We will only use your personal details to contact you in events related to your personal
                        details</p>
                    <p>- We will not share your data with any third parties with the exception of law enforcement
                        officials if a suspected crime has taken place under your personal details</p>
                    <p>- We may use your product purchase data for data analysis</p>
                    <p>- We will not discard your personal data after the order is delivered, in case any of the terms
                        and conditions are violated</p>
                </div>
            </div>
        </div>
    </div>
</template>