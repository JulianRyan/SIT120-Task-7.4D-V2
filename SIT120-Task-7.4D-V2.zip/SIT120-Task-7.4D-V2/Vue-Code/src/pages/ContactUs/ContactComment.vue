<script setup>
import './contact-us.css'
import { ref, defineProps } from 'vue';
import ContactCommentReply from './ContactCommentReply.vue';

const props = defineProps({
    commentId: Number,
    firstName: String,
    commentText: String,
    replies: Array
});

const commentId = ref(props.commentId);
const firstName = ref(props.firstName);
const commentText = ref(props.commentText);
const replies = ref(props.replies);
const collapseToggler = "collapse-" + commentId.value
const collapseRepliesLink = "collapse-replies-" + commentId.value
const collapseControls = "#collapse-replies-" + commentId.value

var commentsShown = ref(false);

function showComments() {
    if (commentsShown.value) {
        document.getElementById('btn-reply-' + commentId.value).innerHTML = "Show replies"; 
        commentsShown.value = false;
    }
    else {
        document.getElementById('btn-reply-' + commentId.value).innerHTML = "Hide replies"; 
        commentsShown.value = true;
    }
}

</script>

<template>
    <div class="row">
        <h6>{{ firstName }}</h6>
        <p class="mb-2">{{ commentText }}
        </p>
    </div>
    <ContactCommentReply v-for="reply in replies" :firstName="reply.firstName" :commentText="reply.commentText"
        :collapseRepliesLink="collapseRepliesLink" />
    <div class="row class mt-2">
        <!--In the future, the text will change to 'hide replies'-->
        <a :id="'btn-reply-' + commentId" type="button" class="btn col-auto px-4 mx-2 rounded-pill text-white comment-button border-0"
            data-bs-toggle="collapse" :href="collapseControls" role="button" aria-expanded="false"
            :aria-controls="collapseControls" @click="showComments">
            Show replies
        </a>
        <button type="button"
            class="btn col-auto px-5 mx-2 rounded-pill text-white comment-button border-0"
            :data-bs-toggle="collapseToggler" role="button">
            Reply
        </button>

    </div>
</template>