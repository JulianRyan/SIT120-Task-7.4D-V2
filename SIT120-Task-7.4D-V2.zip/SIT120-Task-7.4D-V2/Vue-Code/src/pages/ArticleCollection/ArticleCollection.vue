<script setup>
    import './article-collection.css'
</script>

<template>
<div class="modal modal-xl fade" id="articleModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
        aria-labelledby="articleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-scrollable">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="article-collection-modal-img">
                        <div id="article-paragraph">
                            <h1 class="text-center">Egg-cellent Produce has reached 1 million weekly users!</h1>
                            <p class="text-left">Egg-cellent Produce now has over one million people who regularly shops
                                at our stores and
                                online! That is approximately 4% of the population in Australia! We are incredibly
                                grateful to have this many people shopping with us! Thank you to all of those who
                                donated to our charity events! Without your support, we wouldn't be as big as we are
                                today! If you compare one million with Woolworths, well...they have approximately 20
                                million shoppers each week. Hopefully, we can overtake them in the future, but that's
                                just a dream.</p>

                            <p>To cellebrate our milestone of reaching 1 million users, we will be selling our dairy
                                products for 50% off! That's such a huge bargin! We have also updated our website with a
                                more 'cozy' look, so if you're a regular shopper here, you will feel at home here! It's
                                also a fresh new look for our website! Whether you like or don't like the new look,
                                please give us feedback in the 'contact us' page so we can make adjustments based on
                                your feedback! We hope to reach 2 million weekly users in the future!</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <img id="page-banner" class="col-12 img-fluid" src="/images/banner-4.jpg" alt="banner">
    <!-- A list of cards displaying each article. For now, it will be left like this. It looks good, however, I believe it could look better if each article was the same width as the screen. I will consider making readjustments in task 7.4D as this is the draft -->
    <div class="px-0" id="article-content">
        <div class="row font-weight-light text-center  pt-4 pb-2 text-white mx-0">
            <h1>What's New:</h1>
        </div>
        <div class="row mx-0 px-4 pb-3 d-flex flex-wrap justify-content-center">
            <div class="card card-block border-0 p-0 m-2 col-lg-5 col-md-10 col-12" id="article-card-1">
                <div class="card-body form-control border-0">
                    <button class="stretched-link" data-bs-toggle="modal" data-bs-target="#articleModal"></button>
                    <h3 class="text-center">Egg-cellent Produce has reached 1 million weekly users!</h3>
                    <p class="text-left">Egg-cellent Produce now has over one million people who regularly shops at
                        our stores and
                        online! That is approximately 4% of the population in Australia! We are incredibly
                        grateful to have this many people shopping...</p>
                </div>
                <div class="card-footer px-0">
                    <img class="img-fluid" src="/images/city.jpg" alt="city">
                </div>
            </div>
            <div class="card card-block border-0 p-0 m-2 col-lg-5 col-md-10 col-12">
                <div class="card-body form-control border-0">
                    <button class="stretched-link" data-bs-toggle="modal" data-bs-target="#articleModal"></button>
                    <h3 class="text-center">Product Recall on a type of toy</h3>
                    <p>This paragraph is here to describe what is happening in an article. The article
                        could contain information on the company's sales, rewards, product recalls and upcoming
                        events.
                    </p>
                </div>
                <div class="card-footer px-0">
                    <img class="img-fluid col-12" src="/images/toy-recall.jpg" alt="toy"
                        id="article-thumb">
                </div>
            </div>
            <div class="card card-block border-0 p-0 m-2 col-lg-5 col-md-10 col-12" id="article-card-1">
                <div class="card-body form-control border-0">
                    <button class="stretched-link" data-bs-toggle="modal" data-bs-target="#articleModal"></button>
                    <h3 class="text-center">Find a career at our company!</h3>
                    <p>This paragraph is here to describe what is happening in an article. The article
                        could contain information on the company's sales, rewards, product recalls and upcoming
                        events.
                    </p>
                </div>
                <div class="card-footer px-0">
                    <img class="img-fluid col-12" src="/images/career.jpg" alt="career"
                        id="article-thumb">
                </div>
            </div>
            <div class="card card-block border-0 p-0 m-2 col-lg-5 col-md-10 col-12" id="article-card-1">
                <div class="card-body form-control border-0">
                    <button class="stretched-link" data-bs-toggle="modal" data-bs-target="#articleModal"></button>
                    <h3 class="text-center">Christmas is here early!</h3>
                    <p>This paragraph is here to describe what is happening in an article. The article
                        could contain information on the company's sales, rewards, product recalls and upcoming
                        events.
                    </p>
                </div>
                <div class="card-footer px-0">
                    <img class="img-fluid col-12" src="/images/christmas.jpg" alt="christmas"
                        id="article-thumb">
                </div>
            </div>
        </div>

        <!--Will add functionality to view 8-12 more items before the button reappears at the bottom of the collection of items. -->
        <div class="row mx-0 px-4">
            <div class="text-center my-4">
                <button type="button" class="btn p-1 px-2 mx-2 rounded-pill border-0" id="btn-view-more">
                    View more
                </button>
            </div>
        </div>
    </div>
</template>