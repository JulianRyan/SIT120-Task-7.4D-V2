<script setup>
import './product.css'

function productValidation() {
    var returnStatement = true;
    const type = document.getElementById("typeInput").value;
    if (type == "") {
        document.getElementById("typeInput").className = "form-control is-invalid";
        document.getElementById("typeMessage").innerHTML = "Please enter a type for your product"
        document.getElementById("typeMessage").className = "text-danger"
        returnStatement = false;
    }
    else {
        document.getElementById("typeInput").className = "form-control is-valid";
        document.getElementById("typeMessage").innerHTML = "Type input is correct"
        document.getElementById("typeMessage").className = "text-success"
    }

    const quantity = document.getElementById("quantityInput").value;
    if (quantity <= 0) {
        document.getElementById("quantityInput").className = "form-control is-invalid";
        document.getElementById("quantityMessage").innerHTML = "Please enter the quantity of items you would like"
        document.getElementById("quantityMessage").className = "text-danger"
        returnStatement = false;
    }
    else {
        document.getElementById("quantityInput").className = "form-control is-valid";
        document.getElementById("quantityMessage").innerHTML = "Quantity input is correct"
        document.getElementById("quantityMessage").className = "text-success"
    }
    if (returnStatement == true) {
        document.location.href = "/checkout.html"
    }
}

function commentValidation() {
    var returnStatement = true;
    const firstName = document.getElementById("nameInput").value;
    const comment = document.getElementById("commentInput").value;
    const rating = document.getElementById("ratingInput").value
    if (firstName == "" || comment == "" || (rating > 0 || rating <= 5) == false) {
        returnStatement = false;
    }
    if (returnStatement == false) {
        if (firstName == "") {
            document.getElementById("nameInput").className = "form-control is-invalid";
            document.getElementById("nameMessage").innerHTML = "Please enter your name"
            document.getElementById("nameMessage").className = "text-danger"
            document.getElementById("comment-controls").className = "row form align-items-center mx-0"
        }
        else {
            document.getElementById("nameInput").className = "form-control is-valid";
            document.getElementById("nameMessage").innerHTML = "Name input is correct"
            document.getElementById("nameMessage").className = "text-success"
            document.getElementById("comment-controls").className = "row form align-items-center mx-0"
        }

        if (comment == "") {
            document.getElementById("commentInput").className = "form-control is-invalid";
            document.getElementById("commentMessage").innerHTML = "Please enter a comment"
            document.getElementById("commentMessage").className = "px-0 text-danger"
            document.getElementById("comment-controls").className = "row form align-items-center mx-0"
        }
        else {
            document.getElementById("commentInput").className = "form-control is-valid";
            document.getElementById("commentMessage").innerHTML = "Comment input is correct"
            document.getElementById("commentMessage").className = "px-0 text-success"
            document.getElementById("comment-controls").className = "row form align-items-center mx-0"
        }

        const rating = document.getElementById("ratingInput").value;
        if ((rating > 0 || rating <= 5) == false) {
            document.getElementById("ratingMessage").innerHTML = "Please enter a rating"
            document.getElementById("ratingInput").className = "form-control text-center m-0 border-danger";
            document.getElementById("ratingMessage").className = "text-danger"
            returnStatement = false;
        }
        else {
            document.getElementById("ratingMessage").innerHTML = "Rating input is correct"
            document.getElementById("ratingInput").className = "form-control text-center m-0 border-success";
            document.getElementById("ratingMessage").className = "text-success"
            document.getElementById("ratingMessage").value = 0
        }
    }
    else {
        console.log("message sent")
        document.getElementById("nameInput").className = "form-control";
        document.getElementById("nameMessage").innerHTML = ""
        document.getElementById("nameMessage").className = ""

        document.getElementById("commentInput").className = "form-control";
        document.getElementById("commentMessage").innerHTML = ""
        document.getElementById("commentMessage").className = ""

        document.getElementById("ratingInput").className = "form-control text-center";
        document.getElementById("ratingMessage").innerHTML = ""
        document.getElementById("ratingMessage").className = ""
    }
}

function displayRating(ratingInput) {
    var stars = document.getElementById("ratingInput").children
    for (var i = 0; i < stars.length; i++) {
        if (i < ratingInput) {
            document.getElementById("ratingInput").children[i].innerHTML = "&#x2605"
        }
        else {
            document.getElementById("ratingInput").children[i].innerHTML = "&#x2606"
        }
    }
}

function removeRating() {
    var stars = document.getElementById("ratingInput").children
    var value = document.getElementById("ratingInput").value
    for (var i = 0; i < stars.length; i++) {
        if (i < value) {
            document.getElementById("ratingInput").children[i].innerHTML = "&#x2605"
        }
        else {
            document.getElementById("ratingInput").children[i].innerHTML = "&#x2606"
        }
    }
}

function inputRating(value) {
    var stars = document.getElementById("ratingInput").children
    for (var i = 0; i < stars.length; i++) {
        if (value - 1 == i) {
            document.getElementById("ratingInput").value = value
        }
    }
}
</script>

<template>
    <img id="page-banner" class="col-12 img-fluid" src="/images/banner-4.jpg" alt="banner">
    <div class="text-center mt-4 mb-2 text-white">
        <h1 class="font-weight-light text-center pb-2">Chicken Drumsticks 4-Pack</h1>
        <h6 class="card-title">Was $1.99/kg</h6>
        <h3 class="card-title">Now $0.99/kg</h3>
        <h5 class="card-title">Rating: &#x2605;&#x2605;&#x2605;&#x2606;&#x2606;</h5>
    </div>

    <!--A selected product. Do note that the page contents will change depending on what product is selected -->
    <div class="container-fluid">
        <div class="px-2">
            <div class="row px-4 pt-4 align-items-center" id="product-details">
                <div class="col-lg-6 col-12 pb-5 px-4">
                    <img class="img-fluid p-0 rounded-4 w-100 h-100" src="/images/chicken-drumsticks-4.jpg"
                        alt="product" id="product-img">
                </div>
                <div class="col-lg-6 col-12 pb-5 px-4">
                    <div class="form">
                        <div class="mb-4">
                            <label for="productDescription">Description:</label>
                            <p id="productDescription">This paragraph will be the description of the item. The image on
                                the left is supposed to
                                be a
                                product.
                            </p>
                        </div>
                        <div class="mb-4">
                            <!-- In some examples, a product may have a 'type'. In this case, there is no type and the type is disabled. -->
                            <label for="typeInput">Option</label>
                            <select type="text" class="form-control" id="typeInput" value="" required>
                                <option selected disabled value="">Please enter a value...</option>
                                <option value="One">Option 1</option>
                                <option value="Two">Option 2</option>
                                <option value="Three">Option 3</option>
                                <option value="Four">...</option>
                            </select>
                            <div id="typeMessage"></div>
                        </div>
                        <div class="mb-4">
                            <label for="quantityInput">Quantity</label>
                            <input type="number" class="form-control" id="quantityInput"
                                placeholder="Please enter a quantity" value="1" required>
                            <div id="quantityMessage"></div>
                        </div>
                        <h3 class="text-center">Total cost: $0.99</h3>
                        <div class="text-center my-4">
                            <!--Link to Checkout Page-->
                            <button type="submit" class="btn px-2 mx-2 rounded-pill comment-button border-0"
                                id="btn-purchase" @click="productValidation">
                                Purchase Product
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row px-0 mx-0" id="comment-section">
            <div class="col-0 col-md-1 col-lg-2"></div>
            <div class="col-12 col-md-10 col-lg-8">
                <!-- A comments section, similar to the one in the contact-us section without replies. I might have to remove floating labels if I change the floating labels in the contact-us page-->
                <div class="row form px-2 mt-5 mb-4 my-4 mx-0">
                    <label for="commentInput" class="px-0">Feel free to leave us a comment!</label>
                    <textarea class="form-control" id="commentInput"
                        placeholder="Feel free to leave us a comment!"></textarea>
                    <div id="commentMessage" class="px-0"></div>
                </div>

                <div class="row form align-items-end mx-0" id="comment-controls">
                    <div class="col-lg-auto col-sm-6 col-12 mb-4 px-2">
                        <label for="nameInput">First Name:</label>
                        <input type="text" class="form-control" id="nameInput" placeholder="Name">
                        <div id="nameMessage"></div>
                    </div>

                    <div class="col-lg-auto col-sm-6 col-12 mb-4 px-2">
                        <label for="ratingInput">Rating:</label>
                        <div class="form-control text-center m-0 " id="ratingInput" value=0>
                            <button class="px-1 py-0 m-0 rating-star" @mouseenter="displayRating(1)"
                                @mouseleave="removeRating()" @click="inputRating(1)">&#x2606;</button>
                            <button class="px-1 py-0 m-0 rating-star" @mouseenter="displayRating(2)"
                                @mouseleave="removeRating()" @click="inputRating(2)">&#x2606;</button>
                            <button class="px-1 py-0 m-0 rating-star" @mouseenter="displayRating(3)"
                                @mouseleave="removeRating()" @click="inputRating(3)">&#x2606;</button>
                            <button class="px-1 py-0 m-0 rating-star" @mouseenter="displayRating(4)"
                                @mouseleave="removeRating()" @click="inputRating(4)">&#x2606;</button>
                            <button class="px-1 py-0 m-0 rating-star" @mouseenter="displayRating(5)"
                                @mouseleave="removeRating()" @click="inputRating(5)">&#x2606;</button>
                        </div>
                        <div id="ratingMessage"></div>
                    </div>
                    <div class="col-lg-auto col-sm-12 text-center h-100 mb-4 px-2">
                        <!-- <label for="btn-send-comment" id="btn-send-comment-space"></label> -->
                        <button type="button" class="btn px-2 rounded-pill comment-button form-control w-auto"
                            role="button" id="btn-send-comment" @click="commentValidation()">
                            Send Comment
                        </button>
                    </div>
                    <div class="col-lg col-12"></div>
                </div>

                <div class="mb-4 px-2">
                    <div class="card" id="comments">
                        <div class="card-body comment border-0">
                            <div class="row">
                                <h6 class="col-auto">John</h6>
                                <h6 class="col-auto">Rating: &#x2605;&#x2605;&#x2605;&#x2605;&#x2605;</h6>
                            </div>
                            <p>Drumsticks were delicious</p>
                            <hr class="contact-comment-hr mx-0">
                            <div class="row">
                                <h6 class="col-auto">Tom</h6>
                                <h6 class="col-auto">Rating: &#x2605;&#x2605;&#x2605;&#x2605;&#x2606;</h6>
                            </div>
                            <p>I like chicken</p>
                            <hr class="contact-comment-hr mx-0">
                            <div class="row">
                                <h6 class="col-auto">Jill</h6>
                                <h6 class="col-auto">Rating: &#x2605;&#x2605;&#x2605;&#x2605;&#x2605;</h6>
                            </div>
                            <p>Drumsticks are better than Woolworths</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-0 col-md-1 col-lg-2"></div>
        </div>
    </div>
</template>