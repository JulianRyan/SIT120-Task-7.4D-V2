<script setup>
import './about-us.css'
</script>

<template>
    <div class="container-fluid mx-0 px-0">
        <!-- Article modal. When the user clicks on the link in the footer, the modal appears and the reader can read it. I will consider finding a way to move this to an external file once I learn Vue -->
        <!-- In the future, the article displayed will be replaced with text and an image, depending on the image and information passed to the article-->
        <div class="modal modal-xl fade" id="articleModal" data-bs-backdrop="static" data-bs-keyboard="false"
            tabindex="-1" aria-labelledby="articleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-scrollable">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="about-us-article-modal-img">
                            <div id="article-paragraph">
                                <h1 class="text-center">Egg-cellent Produce has reached 1 million weekly users!</h1>
                                <p class="text-left">Egg-cellent Produce now has over one million people who
                                    regularly shops
                                    at our stores and
                                    online! That is approximately 4% of the population in Australia! We are
                                    incredibly
                                    grateful to have this many people shopping with us! Thank you to all of those
                                    who
                                    donated to our charity events! Without your support, we wouldn't be as big as we
                                    are
                                    today! If you compare one million with Woolworths, well...they have
                                    approximately 20
                                    million shoppers each week. Hopefully, we can overtake them in the future, but
                                    that's
                                    just a dream.</p>

                                <p>To cellebrate our milestone of reaching 1 million users, we will be selling our
                                    dairy
                                    products for 50% off! That's such a huge bargin! We have also updated our
                                    website with a
                                    more 'cozy' look, so if you're a regular shopper here, you will feel at home
                                    here! It's
                                    also a fresh new look for our website! Whether you like or don't like the new
                                    look,
                                    please give us feedback in the 'contact us' page so we can make adjustments
                                    based on
                                    your feedback! We hope to reach 2 million weekly users in the future!</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!--Each divider contains an employee and a description related to the employee. For employee x, when x is odd, the image is on the left and when x is even, the image is on the right-->
    <img id="page-banner" class="col-12 img-fluid" src="/images/banner-4.jpg" alt="banner">
    <div class="profile-back pb-5 pe-5">
        <h1 class="font-weight-light text-center text-white py-4 mb-0" id="title">About Us</h1>
        <div class="profile rounded-end-pill ps-0 d-lg-block d-none py-3 align-items-center">
            <div class="row mx-0 ps-0 pe-5">
                <div class="col col-auto profile-img text-center d-flex flex-wrap align-items-center">
                    <img class="img-fluid rounded-circle p-0" src="/images/julian.jpg" alt="employee-1">
                </div>
                <div class="d-flex align-items-center col px-5">
                    <div>
                        <h2 class="text-center">Julian Ryan</h2>
                        <h4>Role: Chief Executive Officer</h4>
                        <!--I am using dashes because the user stories have not been written yet. I will get into detail once task 8.2P is complete.-->
                        <p>Hi, my name is Julian Ryan and I am the chief executive officer of this company. I have been
                            here since the company was originally created. It has been a massive honour to be a part of
                            this huge company. I never imagined we would get this far as a team. My role is to supervise
                            the company and maintain the direction of where we want our company to go.</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="profile rounded-end-5 ps-0 d-lg-none d-block py-3">
            <div class="row mx-0 ps-0">
                <div
                    class="col-12 col-md-6 profile-img text-center d-flex flex-wrap align-items-center justify-content-center">
                    <img class="img-fluid rounded-5 p-0" src="/images/julian.jpg" alt="employee-1">
                </div>
                <div class="d-flex align-items-center col px-5">
                    <div>
                        <h2 class="text-center">Julian Ryan</h2>
                        <h4>Role: Chief Executive Officer</h4>
                        <!--I am using dashes because the user stories have not been written yet. I will get into detail once task 8.2P is complete.-->
                        <p>Hi, my name is Julian Ryan and I am the chief executive officer of this company. I have been
                            here since the company was originally created. It has been a massive honour to be a part of
                            this huge company. I never imagined we would get this far as a team. My role is to supervise
                            the company and maintain the direction of where we want our company to go.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="profile-back pt-5 ps-5">
        <div class="profile rounded-start-pill pe-0 d-lg-block d-none py-3">
            <div class="row mx-0 ps-5 pe-0">
                <div class="d-flex align-items-center col px-5">
                    <div>
                        <h2 class="text-center">Julian Ryan</h2>
                        <h4>Role: Chief Financial Officer</h4>
                        <!--I am using dashes because the user stories have not been written yet. I will get into detail once task 8.2P is complete.-->
                        <p> Hi, my name is Julian Ryan and I am the chief financial officer of this company. I have been
                            working with Julian for the past 12 years. It has been a huge pleasure to be a part of this
                            company. My role is to make sure the vital assets maintaining this company are protected and
                            this company doesn't go bankrupt all of a sudden.
                        </p>
                    </div>
                </div>
                <div class="col col-auto profile-img text-center d-flex flex-wrap align-items-center">
                    <img class="img-fluid rounded-circle p-0" src="/images/julian.jpg" alt="employee-2">
                </div>
            </div>
        </div>
        <div class="profile rounded-start-5 pe-0 d-lg-none d-none d-md-block py-3">
            <div class="row mx-0 pe-0">
                <div class="d-flex align-items-center col-12 col-md-6 px-5">
                    <div>
                        <h2 class="text-center">Julian Ryan</h2>
                        <h4>Role: Chief Financial Officer</h4>
                        <!--I am using dashes because the user stories have not been written yet. I will get into detail once task 8.2P is complete.-->
                        <p> Hi, my name is Julian Ryan and I am the chief financial officer of this company. I have been
                            working with Julian for the past 12 years. It has been a huge pleasure to be a part of this
                            company. My role is to make sure the vital assets maintaining this company are protected and
                            this company doesn't go bankrupt all of a sudden.
                        </p>
                    </div>
                </div>
                <div
                    class="col-12 col-md-6 profile-img text-center d-flex flex-wrap justify-content-center align-items-center">
                    <img class="img-fluid rounded-5 p-0" src="/images/julian.jpg" alt="employee-2">
                </div>
            </div>
        </div>
        <div class="profile rounded-start-5 pe-0 d-lg-none d-md-none d-block py-3">
            <div class="row mx-0 pe-0">
                <div
                    class="col-12 col-md-6 profile-img text-center d-flex flex-wrap justify-content-center align-items-center">
                    <img class="img-fluid rounded-5 p-0" src="/images/julian.jpg" alt="employee-2">
                </div>
                <div class="d-flex align-items-center col-12 col-md-6 px-5">
                    <div>
                        <h2 class="text-center">Julian Ryan</h2>
                        <h4>Role: Chief Financial Officer</h4>
                        <!--I am using dashes because the user stories have not been written yet. I will get into detail once task 8.2P is complete.-->
                        <p> Hi, my name is Julian Ryan and I am the chief financial officer of this company. I have been
                            working with Julian for the past 12 years. It has been a huge pleasure to be a part of this
                            company. My role is to make sure the vital assets maintaining this company are protected and
                            this company doesn't go bankrupt all of a sudden.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!--This section is supposed to represent the Company values. The values aren't final. I made them up as I created the webpage. I may redefine them, depending on the user story-->
    <div class="px-4 contaner-fluid" id="values">
        <div class="row px-0 mx-0">
            <div class="col-sm-1 col-md-0 col-lg-1"></div>
            <div class="col-sm-10 col-md-12 col-lg-10">
                <!-- <div class="row" id="values-title">
                </div> -->
                <div class="mb-5 rounded-5" id="values-content">
                    <div class="row">
                        <h1 class="font-weight-light text-center py-4 mb-0">What we stand for:</h1>
                        <div class="col-12 col-md-4">
                            <div class="px-4 text-center">
                                <h3>Community</h3>
                                <div class="value-img-div d-flex flex-wrap align-items-center justify-content-center">
                                    <img class="img-fluid p-2 value-img" src="/images/community.png" alt="care">
                                </div>
                                <p class="text-left">
                                    Our business started as a small community. Without meeting the interests and needs
                                    of the community, then we aren't worth their attention. Egg-cellent produce wouldn't
                                    be here without the help from all of you, so whether you are India, Thailand,
                                    Bangledesh, etc. or just a local customer, we will provide for you!
                                </p>
                            </div>
                        </div>
                        <div class="col-12 col-md-4">
                            <div class="px-4 text-center">
                                <h3>Care</h3>
                                <div class="value-img-div d-flex flex-wrap align-items-center justify-content-center">
                                    <img class="img-fluid p-2 value-img" src="/images/care.png" alt="community">
                                </div>
                                <p class="text-left">
                                    We provide our products to those who need them. Whenever Christmas or a
                                    public holiday happens, we have products to sell to them. Whenever there is a big
                                    event such as the Royal Melbourne Show going on around one of our stores, we are
                                    here to provide for those who want to spend the whole day there.
                                </p>
                            </div>
                        </div>
                        <div class="col-12 col-md-4">
                            <div class="px-4 text-center">
                                <h3>Lowest Prices</h3>
                                <div class="value-img-div d-flex flex-wrap align-items-center justify-content-center">
                                    <img class="img-fluid p-2 value-img" src="/images/low-prices.png" alt="low prices">
                                </div>
                                <p class="text-left">
                                    We will always try to sell our products for the lowest prices! Groceries are a basic
                                    need for living a healthy and happy life. It shouldn't a few hundred dollars to put
                                    food on your plate! Since we have a strong colloaboration with our farmers, that
                                    won't be the case!
                                </p>
                            </div>
                        </div>
                    </div>

                </div>
                <div class="px-4 pb-5 rounded-5" id="history">
                    <!--I am using dashes because the user stories have not been written yet. I will get into detail once task 8.2P is complete.-->
                    <h1 class="font-weight-light text-center py-4 mb-0">Our purpose:</h1>
                    <p>Our purpose is to provide households with affordable food, while ensuring our products come from
                        ethical and sustainable sources.
                        Our goal is to be more than a grocery store. Our goal is to provide for everyone because
                        everyone has somethings essential they need to buy whether it is carrots, bread, cheese, etc.
                    </p>
                </div>
            </div>
        </div>
        <div class="col-sm-1 col-md-0 col-lg-1"></div>
    </div>

    <div class="history-img">
        <div id="history-box">
            <h1 class="mb-4">How did we get here?</h1>
            <!--I am using dashes because the user stories have not been written yet. I will get into detail once task 8.2P is complete.-->
            <p class="history-paragraph">Egg-cellent Produce started as a small business in 1997 next to a farm.
                Egg-cellent produce only sold dairy products, as well as other produce such as bread and vegetables
                purchased from the farm. Egg-cellent produce was popular for selling Christmas and Easter related
                products during the month these holidays occurred. In 2002, we expanded our business into another area
                and kept growing. In 2006, we expanded our business from Victoria to NSW and by 2011, we had
                successfully launched Egg-cellent produce supermarkets all across Australia. Today, we are a
                multi-billion dollar business determined on feeding families and giving them food to eat every night. To
                this day, Egg-cellent produce is built upon the values that allowed us to thrive as a business.
            </p>
        </div>
    </div>

    <div class="px-4 py-4" id="articles">
        <div class="row mx-0 d-flex flex-wrap justify-content-center">
            <div class="card card-block border-0 p-0 m-2 col-lg-5 col-md-10" id="article-card-1">
                <div class="card-body form-control border-0">
                    <button class="stretched-link" data-bs-toggle="modal" data-bs-target="#articleModal"></button>
                    <h3 class="text-center">Egg-cellent Produce has reached 1 million weekly users!</h3>
                    <p class="text-left">Egg-cellent Produce now has over one million people who regularly shops at
                        our stores and
                        online! That is approximately 4% of the population in Australia! We are incredibly
                        grateful to have this many people shopping...</p>
                </div>
                <div class="card-footer px-0">
                    <img class="img-fluid" src="/images/city.jpg" alt="city">
                </div>
            </div>
            <div class="card card-block border-0 p-0 m-2 col-lg-5 col-md-10">
                <div class="card-body form-control border-0">
                    <button class="stretched-link" data-bs-toggle="modal" data-bs-target="#articleModal"></button>
                    <h3 class="text-center">Product Recall on a type of toy</h3>
                    <p>This paragraph is here to describe what is happening in an article. The article
                        could contain information on the company's sales, rewards, product recalls and upcoming
                        events.
                    </p>
                </div>
                <div class="card-footer px-0">
                    <img class="img-fluid col-12" src="/images/toy-recall.jpg" alt="toy" id="article-thumb">
                </div>
            </div>
        </div>
    </div>
</template>