<template>
    <div class="col-sm-6 p-4 text-center">
        <img class="img-fluid" :src="imgSrc" :alt="imgAlt" id="product-img">
    </div>
</template>

<script setup>
import { ref, defineProps } from 'vue';
import './checkout-product.css'
const props = defineProps({
    imgSrc: String,
    imgAlt: String
});

const imgSrc = ref(props.imgSrc).value;
const imgAlt = ref(props.imgAlt).value;
// console.log(imgSrc);

</script>