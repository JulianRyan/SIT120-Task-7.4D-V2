<template>
    <div class="m-0">
        <div class="row pb-4 px-2 m-0">
            <div class="col-lg-3 col-md-2 col-sm-1"></div>
            <div class="product col-lg-6 col-md-8 col-sm-10 col-12 p-0">
                <div class="card p-0 d-sm-block d-none larger-screen-item">
                    <div class="row rounded-1 p-0 mx-0 align-items-center">
                        <ProductImg :imgSrc="imgSrc" :imgAlt="imgAlt"/>
                        <ProductDetails :productId="productId" :size="'large'" :productName="productName" :price="price"
                            :disabledSelect="disabledSelect" :selectedOption="selectedOption"
                            :unselectedOptions="unselectedOptions" :quantity="quantity" @update-made="getData"
                            :key="productKey" />
                    </div>
                </div>
                <div class="card p-0 d-lg-none d-md-none d-sm-none d-block smaller-screen-item">
                    <div class="row rounded-1 p-0 mx-0 align-items-center">
                        <ProductDetails :productId="productId" :size="'small'" :productName="productName" :price="price"
                            :disabledSelect="disabledSelect" :selectedOption="selectedOption"
                            :unselectedOptions="unselectedOptions" :quantity="quantity" @update-made="getData"
                            :key="productKey" />
                        <ProductImg :imgSrc=imgSrc :imgAlt="imgAlt"/>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-2 col-sm-1"></div>
        </div>
    </div>
</template>
<!-- <script>
import { ref, defineProps } from 'vue';

const props = defineProps({
    productId: Number
});
const productId = ref(props.productId);

export default {
    data() {
        return productId
    }
}
</script> -->
<script setup>
import ProductImg from './ProductImg.vue';
import ProductDetails from './ProductDetails.vue';

import { ref, defineProps } from 'vue';
import './checkout-product.css'

const props = defineProps({
    productId: Number,
    productName: String,
    price: Number,
    selectedOption: String,
    unselectedOptions: Array,
    disabledSelect: Boolean,
    quantity: Number,
    imgSrc: String,
    imgAlt: String,
});

const productId = ref(props.productId);
const productName = ref(props.productName);
const price = ref(props.price);
const selectedOption = ref(props.selectedOption);
const disabledSelect = ref(props.disabledSelect);
const unselectedOptions = ref(props.unselectedOptions);
const quantity = ref(props.quantity);
const imgSrc = ref(props.imgSrc);
const imgAlt = ref(props.imgAlt);

const productKey = ref(0)

const returnData = {
    returnOption: String,
    returnQuantity: Number,
    returnId: Number
};

// const returnOption = ref(props.selectedOption)
// const returnQuantity = ref(props.quantity)

// Key change method: https://michaelnthiessen.com/force-re-render
const forceRerender = () => {
    productKey.value += 1;
};

const emit = defineEmits(['product-data']);

function getData(receiveData) {
    selectedOption.value = receiveData.returnOption
    quantity.value = receiveData.returnQuantity
    forceRerender()
    returnData.returnOption = receiveData.returnOption
    returnData.returnQuantity = receiveData.returnQuantity
    returnData.productId = productId
    // console.log(returnQuantity.value)
    emit('product-data', returnData);
}

</script>