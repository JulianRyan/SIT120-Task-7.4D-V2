<script setup>
import './checkout.css'
import CheckoutProduct from './Product/CheckoutProduct.vue';

import { ref, defineProps } from 'vue';

const products = [
    {
        productId: "0",
        productName: "Cheese and Bacon Shapes",
        price: 3.99,
        selectedOption: "",
        unselectedOptions: null,
        disabledSelect: true,
        quantity: 1,
        imgSrc: '/images/cheese-and-bacon-shapes.jpg',
        imgAlt: 'cheese and bacon shapes'
    },
    {
        productId: "1",
        productName: "A2 Milk",
        price: 0.99,
        selectedOption: "",
        unselectedOptions: {
            "1": 'option 1',
            "2": 'option 2',
            "3": 'option 3',
            "4": 'option 4'
        },
        disabledSelect: false,
        quantity: 2,
        imgSrc: '/images/milk.jpg',
        imgAlt: 'milk'
    }]

function getProductData(productData) {
    // console.log(productData.productId.value)
    for (var i = 0; i < products.length; i++) {
        if (products[i].productId == productData.productId.value) {
            products[i].selectedOption = productData.returnOption
            products[i].quantity = productData.returnQuantity
            console.log(products[i].selectedOption + ", " + products[i].quantity)
        }
    }
}

function validatePurchase() {
    console.log("Javascript function")
    // console.log(products)
    // Validate products
    var returnStatement = true;
    for (var i = 0; i < products.length; i++) {
        const product = products[i]

        if (product.unselectedOptions != null) {
            if (product.selectedOption == "") {
                document.getElementById("optionInput-" + i + "-large").className = "form-control border-0 is-invalid optionInput-" + i + "-large";
                document.getElementById("optionInput-" + i + "-small").className = "form-control border-0 is-invalid optionInput-" + i + "-small";
                document.getElementById("optionMessage-" + i + "-large").innerHTML = "Please enter an option for your product"
                document.getElementById("optionMessage-" + i + "-small").innerHTML = "Please enter an option for your product"
                document.getElementById("optionMessage-" + i + "-large").className = "text-danger optionMessage-" + i + "-large";
                document.getElementById("optionMessage-" + i + "-small").className = "text-danger optionMessage-" + i + "-small";
                returnStatement = false;
            }
            else {
                document.getElementById("optionInput-" + i + "-large").className = "form-control border-0 is-valid optionInput-" + i + "-large";
                document.getElementById("optionInput-" + i + "-small").className = "form-control border-0 is-valid optionInput-" + i + "-small";
                document.getElementById("optionMessage-" + i + "-large").innerHTML = "Option input is correct"
                document.getElementById("optionMessage-" + i + "-small").innerHTML = "Option input is correct"
                document.getElementById("optionMessage-" + i + "-large").className = "text-success optionMessage-" + i + "-large";
                document.getElementById("optionMessage-" + i + "-small").className = "text-success optionMessage-" + i + "-small";
            }
        }

        if (product.quantity <= 0) {
            document.getElementById("quantityInput-" + i + "-large").className = "form-control border-0 is-invalid optionInput-" + i + "-large";
            document.getElementById("quantityInput-" + i + "-small").className = "form-control border-0 is-invalid optionInput-" + i + "-small";
            document.getElementById("quantityMessage-" + i + "-large").innerHTML = "Please enter an option for your product"
            document.getElementById("quantityMessage-" + i + "-small").innerHTML = "Please enter an option for your product"
            document.getElementById("quantityMessage-" + i + "-large").className = "text-danger optionMessage-" + i + "-large";
            document.getElementById("quantityMessage-" + i + "-small").className = "text-danger optionMessage-" + i + "-small";
            returnStatement = false;
        }
        else {
            document.getElementById("quantityInput-" + i + "-large").className = "form-control border-0 is-valid optionInput-" + i + "-large";
            document.getElementById("quantityInput-" + i + "-small").className = "form-control border-0 is-valid optionInput-" + i + "-small";
            document.getElementById("quantityMessage-" + i + "-large").innerHTML = "Option input is correct"
            document.getElementById("quantityMessage-" + i + "-small").innerHTML = "Option input is correct"
            document.getElementById("quantityMessage-" + i + "-large").className = "text-success optionMessage-" + i + "-large";
            document.getElementById("quantityMessage-" + i + "-small").className = "text-success optionMessage-" + i + "-small";
        }
    }


    //Validate purchase
    const firstName = document.getElementById("firstnameInput").value;
    const lastName = document.getElementById("lastnameInput").value;
    const email = document.getElementById("emailInput").value;
    const phone = document.getElementById("phoneInput").value;
    const address = document.getElementById("addressInput").value;
    const suburb = document.getElementById("suburbInput").value;
    const state = document.getElementById("stateInput").value;
    const postcode = document.getElementById("postcodeInput").value;
    const card = document.getElementById("cardInput").value;
    const security = document.getElementById("securityInput").value;
    const expiryMonth = document.getElementById("expiryMonthInput").value;
    const expiryYear = document.getElementById("expiryYearInput").value;

    var phonePattern = /[0-9]{10}/;
    var securityPattern = /[0-9]{3}/;
    var postcodePattern = /[0-9]{4}/;
    var cardPattern = /[0-9]{16}/;
    if (firstName == "") {
        document.getElementById("firstnameInput").className = "form-control is-invalid";
        document.getElementById("firstnameMessage").innerHTML = "Please enter your first name"
        document.getElementById("firstnameMessage").className = "text-danger"
        returnStatement = false;
    }
    else {
        document.getElementById("firstnameInput").className = "form-control is-valid";
        document.getElementById("firstnameMessage").innerHTML = "First name is correct"
        document.getElementById("firstnameMessage").className = "text-success"
    }

    if (lastName == "") {
        document.getElementById("lastnameInput").className = "form-control is-invalid";
        document.getElementById("lastnameMessage").innerHTML = "Please enter your last name"
        document.getElementById("lastnameMessage").className = "text-danger"
        returnStatement = false;
    }
    else {
        document.getElementById("lastnameInput").className = "form-control is-valid";
        document.getElementById("lastnameMessage").innerHTML = "Last name is correct"
        document.getElementById("lastnameMessage").className = "text-success"
    }

    var emailFormat =/@/;
    if (email == "") {
        document.getElementById("emailInput").className = "form-control is-invalid";
        document.getElementById("emailMessage").innerHTML = "Please enter your email address"
        document.getElementById("emailMessage").className = "text-danger"
        returnStatement = false;
    }
    else if (emailFormat.test(email) == false)
    {
        document.getElementById("emailInput").className = "form-control is-invalid";
        document.getElementById("emailMessage").innerHTML = "Your email address has invalid format"
        document.getElementById("emailMessage").className = "text-danger"
        returnStatement = false;   
    }
    else {
        document.getElementById("emailInput").className = "form-control is-valid";
        document.getElementById("emailMessage").innerHTML = "Email input is correct"
        document.getElementById("emailMessage").className = "text-success"
    }

    if (phone == "") {
        document.getElementById("phoneInput").className = "form-control is-invalid";
        document.getElementById("phoneMessage").innerHTML = "Please enter your phone number"
        document.getElementById("phoneMessage").className = "text-danger"
        returnStatement = false;
    }
    else if (phone.length != 10) {
        document.getElementById("phoneInput").className = "form-control is-invalid";
        document.getElementById("phoneMessage").innerHTML = "Phone has an invalid length"
        document.getElementById("phoneMessage").className = "text-danger"
        returnStatement = false;
    }
    else if (phonePattern.test(phone) == false) {
        leftoverCharacters = phone.replace(/([0-9])/gi, '');
        document.getElementById("phoneInput").className = "form-control is-invalid";
        document.getElementById("phoneMessage").innerHTML = "Contains characters '" + leftoverCharacters + "'. Numbers only!"
        document.getElementById("phoneMessage").className = "text-danger"
        returnStatement = false;
    }
    else {
        document.getElementById("phoneInput").className = "form-control is-valid";
        document.getElementById("phoneMessage").innerHTML = "Phone number input is correct"
        document.getElementById("phoneMessage").className = "text-success"
    }




    if (address == "") {
        document.getElementById("addressInput").className = "form-control is-invalid";
        document.getElementById("addressMessage").innerHTML = "Please enter your address correctly"
        document.getElementById("addressMessage").className = "text-danger"
        returnStatement = false;
    }
    else {
        document.getElementById("addressInput").className = "form-control is-valid";
        document.getElementById("addressMessage").innerHTML = "Address input is correct"
        document.getElementById("addressMessage").className = "text-success"
    }

    if (suburb == "") {
        document.getElementById("suburbInput").className = "form-control is-invalid";
        document.getElementById("suburbMessage").innerHTML = "Please enter your suburb correctly"
        document.getElementById("suburbMessage").className = "text-danger"
        returnStatement = false;
    }
    else {
        document.getElementById("suburbInput").className = "form-control is-valid";
        document.getElementById("suburbMessage").innerHTML = "Suburb input is correct"
        document.getElementById("suburbMessage").className = "text-success"
    }

    if (state == "") {
        document.getElementById("stateInput").className = "form-control is-invalid";
        document.getElementById("stateMessage").innerHTML = "Please enter your state correctly"
        document.getElementById("stateMessage").className = "text-danger"
        returnStatement = false;
    }
    else {
        document.getElementById("stateInput").className = "form-control is-valid";
        document.getElementById("stateMessage").innerHTML = "State input is correct"
        document.getElementById("stateMessage").className = "text-success"
    }

    if (postcode == "") {
        document.getElementById("postcodeInput").className = "form-control is-invalid";
        document.getElementById("postcodeMessage").innerHTML = "Please enter your postcode correctly"
        document.getElementById("postcodeMessage").className = "text-danger"
        returnStatement = false;
    }
    else if (postcode.length != 4) {
        document.getElementById("postcodeInput").className = "form-control is-invalid";
        document.getElementById("postcodeMessage").innerHTML = "Postcode has an invalid length"
        document.getElementById("postcodeMessage").className = "text-danger"
        returnStatement = false;
    }
    else if (postcodePattern.test(postcode) == false) {
        leftoverCharacters = postcode.replace(/([0-9])/gi, '');
        document.getElementById("postcodeInput").className = "form-control is-invalid";
        document.getElementById("postcodeMessage").innerHTML = "Contains characters '" + leftoverCharacters + "'. Numbers only!"
        document.getElementById("postcodeMessage").className = "text-danger"
        returnStatement = false;
    }
    else {
        document.getElementById("postcodeInput").className = "form-control is-valid";
        document.getElementById("postcodeMessage").innerHTML = "Type input is correct"
        document.getElementById("postcodeMessage").className = "text-success"
    }




    if (card == "") {
        document.getElementById("cardInput").className = "form-control is-invalid";
        document.getElementById("cardMessage").innerHTML = "Please enter your card number correctly"
        document.getElementById("cardMessage").className = "text-danger"
        returnStatement = false;
    }
    else if (card.length != 16) {
        document.getElementById("cardInput").className = "form-control is-invalid";
        document.getElementById("cardMessage").innerHTML = "Card number has an invalid length"
        document.getElementById("cardMessage").className = "text-danger"
        returnStatement = false;
    }
    else if (cardPattern.test(card) == false) {
        leftoverCharacters = card.replace(/([0-9])/gi, '');
        document.getElementById("cardInput").className = "form-control is-invalid";
        document.getElementById("cardMessage").innerHTML = "Contains characters '" + leftoverCharacters + "'. Numbers only!"
        document.getElementById("cardMessage").className = "text-danger"
        returnStatement = false;
    }
    else {
        document.getElementById("cardInput").className = "form-control is-valid";
        document.getElementById("cardMessage").innerHTML = "Card number input is correct"
        document.getElementById("cardMessage").className = "text-success"
    }

    if (security == "") {
        document.getElementById("securityInput").className = "form-control is-invalid";
        document.getElementById("securityMessage").innerHTML = "Please enter your security code correctly"
        document.getElementById("securityMessage").className = "text-danger"
        returnStatement = false;
    }
    else if (security.length != 3) {
        document.getElementById("securityInput").className = "form-control is-invalid";
        document.getElementById("securityMessage").innerHTML = "Security code number has an invalid length"
        document.getElementById("securityMessage").className = "text-danger"
        returnStatement = false;
    }
    else if (securityPattern.test(security) == false) {
        leftoverCharacters = security.replace(/([0-9])/gi, '');
        document.getElementById("securityInput").className = "form-control is-invalid";
        document.getElementById("securityMessage").innerHTML = "Contains characters '" + leftoverCharacters + "'. Numbers only!"
        document.getElementById("securityMessage").className = "text-danger"
        returnStatement = false;
    }
    else {
        document.getElementById("securityInput").className = "form-control is-valid";
        document.getElementById("securityMessage").innerHTML = "Security code input is correct"
        document.getElementById("securityMessage").className = "text-success"
    }

    if (expiryMonth == "") {
        document.getElementById("expiryMonthInput").className = "form-control is-invalid";
        document.getElementById("expiryMessage").innerHTML = "Please enter your expiry date correctly"
        document.getElementById("expiryMessage").className = "text-danger"
        returnStatement = false;
    }
    else if (expiryMonth > 12 || expiryMonth < 1) {
        document.getElementById("expiryMonthInput").className = "form-control is-invalid";
        document.getElementById("expiryMessage").innerHTML = "Please enter your expiry date correctly"
        document.getElementById("expiryMessage").className = "text-danger"
        returnStatement = false;
    }
    else if ((expiryMonth <= 12 || expiryMonth >= 1) && (expiryYear <= 31 || expiryYear >= 1)) {
        document.getElementById("expiryMonthInput").className = "form-control is-valid";
        document.getElementById("expiryYearInput").className = "form-control is-valid";
        document.getElementById("expiryMessage").innerHTML = "Expiry date is correct"
        document.getElementById("expiryMessage").className = "text-success"
    }

    if (expiryYear == "") {
        document.getElementById("expiryYearInput").className = "form-control is-invalid";
        document.getElementById("expiryMessage").innerHTML = "Please enter your expiry date correctly"
        document.getElementById("expiryMessage").className = "text-danger"
        returnStatement = false;
    }
    else if (expiryYear > 31 || expiryYear < 1) {
        document.getElementById("expiryMonthInput").className = "form-control is-invalid";
        document.getElementById("expiryMessage").innerHTML = "Please enter your expiry date correctly"
        document.getElementById("expiryMessage").className = "text-danger"
        returnStatement = false;
    }

    if (returnStatement == true) {
        document.location.href = "/"
    }
}

// console.log(quantity.value)

// console.log(products[0].quantity)
</script>

<!-- '/images/cheese-and-bacon-shapes.jpg' -->
<template>
    <img id="page-banner" class="col-12 img-fluid" src="/images/banner-4.jpg" alt="banner">
    <div class="container-fluid p-0">
        <div class="m-0 text-white" id="title">
            <!-- <div id="header-space"></div> -->
            <h1 class="font-weight-light text-center m-0 py-4">Checkout</h1>
        </div>

        <!--Each row here contains an item. In the future, if a person clicks on the 'X', I will consider adding a message box asking the user if they would like to remove the item from the cart.-->
        <div v-for="product in products" id="products-section">
            <CheckoutProduct :productId=product.productId :productName=product.productName :price=product.price
                :disabledSelect=product.disabledSelect :selectedOption=product.selectedOption
                :unselectedOptions=product.unselectedOptions :quantity=product.quantity :imgSrc=product.imgSrc :imgAlt="product.imgAlt"
                class="product" @product-data="getProductData" />
        </div>
        <!-- <CheckoutProduct :productName=products[1].productName :price=products[1].price
            :disabledSelect=products[1].disabledSelect :selectedOption=products[1].selectedOption
            :unselectedOptions=products[1].unselectedOptions :quantity=products[1].quantity
            :imgSrc=products[1].imgSrc /> -->
        <div id="total-cost" class="m-0 p-0">
            <h2 class="font-weight-light text-white text-center">Total Cost:</h2>
            <h3 class="text-white font-weight-light text-center m-0 pb-4">$10.99</h3>
        </div>
        <!-- Form details. For now, I have added no validation, as this is a draft, however I will add it in a future task -->
        <!-- I will consider replacing the floating labels with other labels in the future. For now, I will leave them here and consider making adjustments in task 7.4D-->
        <div class="container-fluid m-0 p-0" id="payment-details">
            <!--Contact details are the first name, last name, email and phone number-->
            <div class="row px-0 mx-0">
                <div class="col-sm-1 col-md-0 col-lg-1"></div>
                <div class="col-sm-10 col-md-12 col-lg-10">
                    <h2 class="font-weight-light text-center pb-0 pt-4 text-white">Contact Details</h2>
                    <div class="row">
                        <div class="col-sm-6 mb-4">
                            <div class="form">
                                <label for="firstnameInput" class="text-white">First Name</label>
                                <input type="text" class="form-control border-0" id="firstnameInput"
                                    placeholder="First Name" required>
                                <div id="firstnameMessage"></div>
                            </div>
                        </div>

                        <div class="col-sm-6 mb-4">
                            <div class="form">
                                <label for="lastnameInput" class="text-white">Last Name</label>
                                <input type="text" class="form-control border-0" id="lastnameInput"
                                    placeholder="Last Name" required>
                                <div id="lastnameMessage"></div>
                            </div>
                        </div>
                    </div>
                    <div class="row pb-2">
                        <div class="col-sm-6 mb-4">
                            <div class="form">
                                <label for="emailInput" class="text-white">Email</label>
                                <input type="email" class="form-control border-0" id="emailInput" placeholder="Email"
                                    required>
                                <div id="emailMessage"></div>
                            </div>
                        </div>
                        <!--An example where floating labels can be an issue.-->
                        <div class="col-sm-6 mb-4">
                            <div class="form">
                                <label for="phoneInput" class="text-white">Mobile</label>
                                <div class="input-group" id="mobileDiv">
                                    <span class="input-group-text border-0" id="mobileAddon">+61</span>
                                    <input type="text" placeholder="xxxx xxx xxx" class="form-control border-0"
                                        id="phoneInput" maxlength="10" aria-describedby="mobileAddon"
                                        pattern="[0-9]{10}" required>
                                </div>
                                <div id="phoneMessage"></div>
                            </div>
                        </div>
                    </div>

                    <!--Location details include a street address, a suburb, a state and a postcode.-->
                    <h2 class="font-weight-light text-center py-0 text-white">Location Details</h2>
                    <div class="row">
                        <div class="col-sm-6 mb-4">
                            <div class="form">
                                <label for="addressInput" class="text-white">Address</label>
                                <input type="text" class="form-control border-0" id="addressInput" placeholder="Address"
                                    required>
                                <div id="addressMessage"></div>
                            </div>
                        </div>

                        <div class="col-sm-6 mb-4">
                            <div class="form">
                                <label for="suburbInput" class="text-white">Suburb</label>
                                <input type="text" class="form-control border-0" id="suburbInput" placeholder="Suburb"
                                    required>
                                <div id="suburbMessage"></div>
                            </div>
                        </div>
                    </div>
                    <div class="row mb-4">
                        <div class="col-sm-6 mb-4">
                            <div class="form">
                                <label for="stateInput" class="text-white">State</label>
                                <select type="text" class="form-control border-0" id="stateInput" placeholder=""
                                    value="" required>
                                    <option selected value="" disabled>Choose...</option>
                                    <option value="WA">WA</option>
                                    <option value="NT">NT</option>
                                    <option value="SA">SA</option>
                                    <option value="QLD">QLD</option>
                                    <option value="NSW">NSW</option>
                                    <option value="ACT">ACT</option>
                                    <option value="VIC">VIC</option>
                                    <option value="TAS">TAS</option>
                                </select>
                                <div id="stateMessage"></div>
                            </div>
                        </div>

                        <div class="col-sm-6 mb-4">
                            <div class="form">
                                <label for="postcodeInput" class="text-white">Postcode</label>
                                <input type="number" class="form-control border-0" id="postcodeInput" maxlength="4"
                                    pattern="+61 [0-9]{4}" placeholder="Postcode" required>
                                <div id="postcodeMessage"></div>
                            </div>
                        </div>
                    </div>

                    <!--Banking details-->
                    <div class="row mb-4">
                        <h2 class="font-weight-light text-center py-0 text-white">Credit Card Details</h2>
                        <div class="col-lg-6 mb-4">
                            <div class="form">
                                <label for="cardInput" class="text-white">Card Number</label>
                                <input type="text" class="form-control border-0" id="cardInput"
                                    placeholder="XXXX XXXX XXXX XXXX" pattern="[0-9]{16}" maxlength="16" required>
                                <div id="cardMessage"></div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-6 mb-4">
                            <div class="form">
                                <label for="securityInput" class="text-white">Security Code</label>
                                <input type="text" class="form-control border-0" id="securityInput" placeholder="XXX"
                                    pattern="[0-9]{3}" maxlength="3" required>
                                <div id="securityMessage"></div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-6 mb-4">
                            <div class="form">
                                <label for="expiryDiv" class="text-white">Expiry Date</label>
                                <div class="input-group border-0" id="expiryDiv">
                                    <input type="text" placeholder="MM" class="form-control" id="expiryMonthInput"
                                        maxlength="2" aria-describedby="cardExpiryAddon" pattern="[0-9]{2}">
                                    <span class="input-group-text border-0" id="cardExpiryAddon">/</span>
                                    <input type="text" placeholder="DD" class="form-control" id="expiryYearInput"
                                        maxlength="2" aria-describedby="cardExpiryAddon" pattern="[0-9]{2}" required>
                                </div>
                                <div id="expiryMessage"></div>
                            </div>
                        </div>
                    </div>
                </div>

                <!--Purchases the order and links back to the Home Page-->
                <div class="text-center mb-4">
                    <button type="submit" class="btn p-1 px-2 mx-2 rounded-pill border-0" id="submit-order"
                        @click="validatePurchase()">
                        Submit order
                    </button>
                </div>
            </div>
            <div class="col-sm-1 col-md-0 col-lg-1"></div>
        </div>
    </div>
</template>